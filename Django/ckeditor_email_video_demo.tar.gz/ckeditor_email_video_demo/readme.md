import sentry_sdk
sentry_sdk.init("https://c1da2c6fa07a4029a40fa9b12c61c29a@sentry.io/1428821")