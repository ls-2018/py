package main

import (
	"github.com/astaxie/beego"
)

type MainController struct {
	beego.Controller
}

func (this *MainController) Get() {
	this.Ctx.WriteString("光环")
	//this.Ctx.WriteString("hello world!")
}

func main() {
	beego.Router("/", &MainController{})
	beego.Run("0.0.0.0:8000")
}

//go get github.com/astaxie/beego
