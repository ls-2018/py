构建需要注意的点

尽量减少layer
container 改为 label
多阶段构建