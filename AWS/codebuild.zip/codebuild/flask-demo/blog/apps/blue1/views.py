from . import blue1


@blue1.route('/')
def index():
    return "flask-demo"
