from flask import Blueprint

blue1 = Blueprint("", __name__)
from .views import *
