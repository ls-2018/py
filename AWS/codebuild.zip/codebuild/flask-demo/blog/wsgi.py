from apps import create_app
from apps.blue1 import blue1

app = create_app()
app.register_blueprint(blue1)
